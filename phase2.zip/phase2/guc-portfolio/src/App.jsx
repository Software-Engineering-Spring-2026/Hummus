import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { AppProvider, useApp } from './context/AppContext'
import { ToastContainer } from './components/Components'
import { LandingPage } from './pages/LandingPage'
import { LoginPage, RegisterPage, ForgotPasswordPage } from './pages/Auth/AuthPages'
import { StudentDashboard, StudentPortfolio, StudentNotifications, StudentFavorites, StudentSettings } from './pages/Student/StudentPages'
import { StudentProjects } from './pages/Student/StudentProjects'
import { ExplorePage, MessagesPage } from './pages/Explore/ExplorePage'

function Protected({ children, role }) {
  const { currentUser } = useApp()
  if (!currentUser) return <Navigate to="/login" replace />
  if (role && currentUser.role !== role) return <Navigate to={`/${currentUser.role}`} replace />
  return children
}

function AppRoutes() {
  const { currentUser } = useApp()
  return (
    <>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/login" element={currentUser ? <Navigate to={`/${currentUser.role}`} /> : <LoginPage />} />
        <Route path="/register" element={currentUser ? <Navigate to={`/${currentUser.role}`} /> : <RegisterPage />} />
        <Route path="/forgot-password" element={<ForgotPasswordPage />} />
        <Route path="/explore" element={<ExplorePage />} />
        <Route path="/student" element={<Protected role="student"><StudentDashboard /></Protected>} />
        <Route path="/student/portfolio" element={<Protected role="student"><StudentPortfolio /></Protected>} />
        <Route path="/student/projects" element={<Protected role="student"><StudentProjects /></Protected>} />
        <Route path="/student/favorites" element={<Protected role="student"><StudentFavorites /></Protected>} />
        <Route path="/student/notifications" element={<Protected role="student"><StudentNotifications /></Protected>} />
        <Route path="/student/settings" element={<Protected role="student"><StudentSettings /></Protected>} />
        <Route path="/student/messages" element={<Protected role="student"><MessagesPage role="student" /></Protected>} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
      <ToastContainer />
    </>
  )
}

export default function App() {
  return (
    <AppProvider>
      <BrowserRouter>
        <AppRoutes />
      </BrowserRouter>
    </AppProvider>
  )
}
